#ifndef TACHCLIENT_H
#define TACHCLIENT_H

#include <Arduino.h>
#include "M4CommsHelpers.h"
#include "StateManager.h"
#include "Logging.h"

class TachClient {
 public:
  static TachClient& Instance();

  void Begin();
  void OnPullStateChanged(int ignored);
  void Poll(unsigned long nowMs);
  void HandleJson(uint8_t* senderMac, int rssi, int action, float valueRpm, bool hasValue);

  void clearPair();

 private:
  struct Candidate {
    bool valid = false;
    uint8_t mac[6] = {0};
    int rssi = -999;
    unsigned long lastSeen = 0;
  };

  static constexpr unsigned long kDiscoveryMs = 400;   // wait this long after STAGED to pick
  static constexpr unsigned long kFreshMs     = 3000;  // candidate freshness
  static constexpr unsigned long kPollMs      = 150;   // request interval to paired TSS
  static constexpr unsigned long kTimeoutMs   = 1000;  // rpm timeout

  static const uint8_t BROADCAST_MAC[6];

  void noteCandidate(uint8_t* mac, int rssi);
  int  strongestIndex() const;
  void chooseStrongest();
  void sendDiscovery();
  void requestRpm();

  // runtime state
  bool inStaged_   = false;
  unsigned long stagedAt_ = 0;

  bool havePair_   = false;
  bool connected_  = false;
  uint8_t pairedMac_[6] = {0};

  float liveRpm_ = 0.0f;
  unsigned long lastPollMs_ = 0;
  unsigned long lastRpmMs_  = 0;

  static constexpr int kMax = 8;
  Candidate c_[kMax];
};

#endif
