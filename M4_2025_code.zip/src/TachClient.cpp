#include "TachClient.h"
#include <ArduinoJson.h>

static const uint8_t BCAST_ADDR[6] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
const uint8_t TachClient::BROADCAST_MAC[6] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};

TachClient& TachClient::Instance() {
  static TachClient inst;
  return inst;
}

void TachClient::Begin() {
  // start clean
  clearPair();
  for (int i = 0; i < kMax; ++i) c_[i] = Candidate{};
  StateManager::setTSSConnected(false);
  StateManager::setTSSRssi(-999);
}

void TachClient::OnPullStateChanged(int /*ignored*/) {
  PullState ps = StateManager::getPullState();

  if (!StateManager::getIsAutoConnectTractor()) {
    LOGW("[TachClient] autoConnect disabled");
    inStaged_ = false;
    return;
  }

  if (ps == PullState::STAGED) {
    if (!inStaged_) {
      inStaged_ = true;
      stagedAt_ = millis();
      // fresh discovery window per stage
      for (int i = 0; i < kMax; ++i) c_[i] = Candidate{};
      clearPair();
      sendDiscovery();
      LOGI("[TachClient] entered STAGED, discovery started");
    }
  } else {
    inStaged_ = false;
  }
}

void TachClient::Poll(unsigned long nowMs) {
  // after a short discovery window, lock on the strongest
  if (inStaged_ && !havePair_ && stagedAt_ && (nowMs - stagedAt_ >= kDiscoveryMs)) {
    chooseStrongest();
  }

  // keep asking the paired TSS for RPM
  if (havePair_ && nowMs - lastPollMs_ >= kPollMs) {
    lastPollMs_ = nowMs;
    requestRpm();
  }

  // timeout handling
  if (havePair_ && nowMs - lastRpmMs_ > kTimeoutMs) {
    if (connected_) LOGW("[TachClient] RPM timeout");
    connected_ = false;
    liveRpm_ = 0.0f;
    StateManager::setTSSConnected(false);
  }

  // always push current rpm to state for UI
  StateManager::setRPM(liveRpm_);
}

void TachClient::HandleJson(uint8_t* senderMac,
                            int rssi,
                            int action,
                            float valueRpm,
                            bool hasValue) {
  // Any RPM frame counts as a sighting
  if (action == SEND_RPM) {
    noteCandidate(senderMac, rssi);

    if (havePair_ && memcmp(senderMac, pairedMac_, 6) == 0) {
      // it is our paired TSS
      if (hasValue) {
        liveRpm_ = valueRpm;
        lastRpmMs_ = millis();
      }
      if (!connected_) {
        connected_ = true;
        LOGI("[TachClient] TSS link up");
      }
      StateManager::setTSSConnected(true);
      StateManager::setTSSRssi(rssi);
    }
    return;
  }

  // If you later add a PROXIMITY reply action, handle it here
  // Example:
  // if (action == SEND_PROXIMITY) { noteCandidate(senderMac, rssi); }
}

void TachClient::sendDiscovery() {
  // mirror the working sample: ask for proximity from tach sensors
  StaticJsonDocument<64> doc;
  doc["action"] = SEND_PROXIMITY;
  doc["reqDevice"] = M4_TACH_SENSOR;
  String payload;
  serializeJson(doc, payload);

  sendMessage(BROADCAST_MAC, BROADCAST, SEND_PROXIMITY, payload, HIGH_PRIORITY);
  LOGD("[TachClient] broadcast SEND_PROXIMITY for M4_TACH_SENSOR");
}

void TachClient::noteCandidate(uint8_t* mac, int rssi) {
  unsigned long now = millis();

  // update if present
  for (int i = 0; i < kMax; ++i) {
    if (c_[i].valid && memcmp(c_[i].mac, mac, 6) == 0) {
      c_[i].rssi = rssi;
      c_[i].lastSeen = now;
      return;
    }
  }
  // insert if free slot exists
  for (int i = 0; i < kMax; ++i) {
    if (!c_[i].valid) {
      c_[i].valid = true;
      memcpy(c_[i].mac, mac, 6);
      c_[i].rssi = rssi;
      c_[i].lastSeen = now;
      return;
    }
  }
  // replace oldest
  int oldest = 0;
  for (int i = 1; i < kMax; ++i) {
    if (c_[i].lastSeen < c_[oldest].lastSeen) oldest = i;
  }
  c_[oldest].valid = true;
  memcpy(c_[oldest].mac, mac, 6);
  c_[oldest].rssi = rssi;
  c_[oldest].lastSeen = now;
}

int TachClient::strongestIndex() const {
  unsigned long now = millis();
  int best = -1;
  int bestRssi = -999;
  for (int i = 0; i < kMax; ++i) {
    if (!c_[i].valid) continue;
    if (now - c_[i].lastSeen > kFreshMs) continue;
    if (c_[i].rssi > bestRssi) {
      bestRssi = c_[i].rssi;
      best = i;
    }
  }
  return best;
}

void TachClient::chooseStrongest() {
  int idx = strongestIndex();
  if (idx < 0) {
    // nothing heard yet, poke again
    sendDiscovery();
    return;
  }

  memcpy(pairedMac_, c_[idx].mac, 6);
  havePair_ = true;
  connected_ = false;

  StateManager::setPairedTractorAddress(pairedMac_);
  StateManager::setTSSRssi(c_[idx].rssi);

  LOGI("[TachClient] paired %02X:%02X:%02X:%02X:%02X:%02X rssi=%d",
       pairedMac_[0], pairedMac_[1], pairedMac_[2],
       pairedMac_[3], pairedMac_[4], pairedMac_[5],
       c_[idx].rssi);
}

void TachClient::clearPair() {
  havePair_ = false;
  connected_ = false;
  memset(pairedMac_, 0, sizeof(pairedMac_));
}

void TachClient::requestRpm() {
  if (!havePair_) return;
  // ask only the paired TSS
  sendMessage(pairedMac_, REQUEST, SEND_RPM, "{}", MEDIUM_PRIORITY);
}
